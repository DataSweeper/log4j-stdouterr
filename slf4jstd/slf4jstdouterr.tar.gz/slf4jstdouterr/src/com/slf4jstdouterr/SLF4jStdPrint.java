package com.slf4jstdouterr;
import com.slf4jstdouterr.LoggingOutputStream;

import java.io.PrintStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SLF4jStdPrint {
    private static final Logger logger = LoggerFactory.getLogger("stdout");
    private static final Logger logger1 = LoggerFactory.getLogger("stderr");
    public static void setStd() {
	LoggingOutputStream los = new LoggingOutputStream(logger);
        LoggingOutputStream los1 = new LoggingOutputStream(logger1);
	System.setOut(outputFile(los));
	System.setErr(outputFile(los1));
    }

    protected static PrintStream outputFile(LoggingOutputStream name) {
        return new PrintStream(name, true);
    }
}