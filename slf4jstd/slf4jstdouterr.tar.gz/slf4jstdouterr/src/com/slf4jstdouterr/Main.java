package com.slf4jstdouterr;

/**
 * Created by siva-2356 on 14/9/16.
 */
public class Main {
    public static void main(String[] args) {
    SLF4jStdPrint.setStd();
    try {
	System.out.println("this is an exception.");
        int a = 10/0;
    } catch(ArithmeticException e) {
        e.printStackTrace();
    }
    System.out.println("hi this is sivagnanam");
    }
}
