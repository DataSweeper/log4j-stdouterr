package com.slf4jstdouterr;

public class OutString {
    private String str = null;

    public OutString () {
	System.out.println("outstring called.");
    }

    public void append(String str) {
	if (this.str == null) {
	    this.str = str;
	}
	else {
	    this.str += str;
	    System.out.println(this.str);
	}
    }

    public void reset () {
	this.str = null;
    }

    public String toString () {
	if (this.str != null)
	    return new String(this.str);
	return new String();
    }
}